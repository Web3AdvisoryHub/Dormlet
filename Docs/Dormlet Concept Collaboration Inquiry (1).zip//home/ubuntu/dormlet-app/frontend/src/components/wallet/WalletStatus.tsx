import React, { useEffect, useState } from 'react';
import { useWallet } from '../../hooks/useWallet';
import { ethers } from 'ethers';
import axios from 'axios';

const WalletStatus: React.FC = () => {
  const { address, isConnected, chainId, provider } = useWallet();
  const [balance, setBalance] = useState<string>('0');
  const [networkName, setNetworkName] = useState<string>('');

  useEffect(() => {
    const getWalletDetails = async () => {
      if (isConnected && address && provider) {
        try {
          // Get wallet balance
          const balanceWei = await provider.getBalance(address);
          const balanceEth = ethers.utils.formatEther(balanceWei);
          setBalance(parseFloat(balanceEth).toFixed(4));

          // Get network name
          const network = await provider.getNetwork();
          const networks: Record<number, string> = {
            1: 'Ethereum Mainnet',
            5: 'Goerli Testnet',
            137: 'Polygon Mainnet',
            80001: 'Mumbai Testnet',
            10: 'Optimism',
            42161: 'Arbitrum One'
          };
          setNetworkName(networks[network.chainId] || `Chain ID: ${network.chainId}`);
        } catch (error) {
          console.error('Error fetching wallet details:', error);
        }
      }
    };

    getWalletDetails();
  }, [isConnected, address, provider, chainId]);

  if (!isConnected) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <h2 className="text-xl font-semibold mb-3">Wallet Status</h2>
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-gray-600">Address:</span>
          <span className="font-medium">{`${address?.substring(0, 6)}...${address?.substring(address.length - 4)}`}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Balance:</span>
          <span className="font-medium">{balance} ETH</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Network:</span>
          <span className="font-medium">{networkName}</span>
        </div>
      </div>
    </div>
  );
};

export default WalletStatus;
