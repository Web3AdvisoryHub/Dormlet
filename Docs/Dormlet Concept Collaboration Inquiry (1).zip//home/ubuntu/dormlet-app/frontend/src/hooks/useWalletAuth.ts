import { useEffect } from 'react';
import { useWallet } from '../../hooks/useWallet';
import axios from 'axios';
import { ethers } from 'ethers';
import { SiweMessage } from 'siwe';

// Custom hook for wallet authentication
export const useWalletAuth = () => {
  const { address, isConnected, provider } = useWallet();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Check if user has a valid token on mount
  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      validateToken(token);
    }
  }, []);

  // Validate existing token
  const validateToken = async (token: string) => {
    try {
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/api/auth/validate`,
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      
      if (response.data.valid) {
        setAuthToken(token);
        setIsAuthenticated(true);
      } else {
        localStorage.removeItem('auth_token');
        setAuthToken(null);
        setIsAuthenticated(false);
      }
    } catch (error) {
      console.error('Error validating token:', error);
      localStorage.removeItem('auth_token');
      setAuthToken(null);
      setIsAuthenticated(false);
    }
  };

  // Sign in with Ethereum
  const signInWithEthereum = async () => {
    if (!isConnected || !address || !provider) {
      setAuthError('Wallet not connected');
      return;
    }

    setIsAuthenticating(true);
    setAuthError(null);

    try {
      // Get nonce from server
      const nonceResponse = await axios.get(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/api/auth/nonce`
      );
      const { nonce } = nonceResponse.data;

      // Create SIWE message
      const domain = window.location.host;
      const origin = window.location.origin;
      
      const message = new SiweMessage({
        domain,
        address,
        statement: 'Sign in with Ethereum to access Dormlet',
        uri: origin,
        version: '1',
        chainId: provider.network.chainId,
        nonce
      });
      
      const messageToSign = message.prepareMessage();
      
      // Request signature from wallet
      const signer = provider.getSigner();
      const signature = await signer.signMessage(messageToSign);
      
      // Verify signature with backend
      const verifyResponse = await axios.post(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/api/auth/verify`,
        {
          message: messageToSign,
          signature
        }
      );
      
      const { token } = verifyResponse.data;
      
      // Store token and update state
      localStorage.setItem('auth_token', token);
      setAuthToken(token);
      setIsAuthenticated(true);
      setIsAuthenticating(false);
    } catch (error) {
      console.error('Error signing in with Ethereum:', error);
      setAuthError(error.message || 'Failed to authenticate');
      setIsAuthenticating(false);
    }
  };

  // Sign out
  const signOut = () => {
    localStorage.removeItem('auth_token');
    setAuthToken(null);
    setIsAuthenticated(false);
  };

  return {
    isAuthenticated,
    authToken,
    isAuthenticating,
    authError,
    signInWithEthereum,
    signOut
  };
};
