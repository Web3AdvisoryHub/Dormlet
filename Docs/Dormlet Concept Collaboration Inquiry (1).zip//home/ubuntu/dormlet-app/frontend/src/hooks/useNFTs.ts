import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { RootState } from '../store';
import { 
  fetchNFTsRequest, 
  fetchNFTsSuccess, 
  fetchNFTsFailure 
} from '../store/nftSlice';

export const useNFTs = () => {
  const dispatch = useDispatch();
  const { address } = useSelector((state: RootState) => state.wallet);
  const { nfts, isLoading, error, selectedNFT } = useSelector(
    (state: RootState) => state.nft
  );

  const fetchNFTs = async () => {
    if (!address) return;

    dispatch(fetchNFTsRequest());
    try {
      // Using Alchemy API to fetch NFTs
      const alchemyKey = process.env.NEXT_PUBLIC_ALCHEMY_API_KEY;
      const baseURL = `https://eth-mainnet.g.alchemy.com/v2/${alchemyKey}/getNFTs/`;
      const url = `${baseURL}?owner=${address}`;

      const response = await axios.get(url);
      
      // Transform the response data to match our NFT interface
      const formattedNFTs = response.data.ownedNfts.map(nft => ({
        id: `${nft.contract.address}-${nft.id.tokenId}`,
        tokenId: nft.id.tokenId,
        contractAddress: nft.contract.address,
        chainId: 1, // Ethereum mainnet
        name: nft.title || 'Unnamed NFT',
        description: nft.description || '',
        image: nft.media[0]?.gateway || '',
        metadata: nft.metadata
      }));

      dispatch(fetchNFTsSuccess(formattedNFTs));
    } catch (error) {
      console.error('Error fetching NFTs:', error);
      dispatch(fetchNFTsFailure(error.message || 'Failed to fetch NFTs'));
    }
  };

  // Fetch NFTs when wallet address changes
  useEffect(() => {
    if (address) {
      fetchNFTs();
    }
  }, [address]);

  return {
    nfts,
    isLoading,
    error,
    selectedNFT,
    fetchNFTs,
  };
};
